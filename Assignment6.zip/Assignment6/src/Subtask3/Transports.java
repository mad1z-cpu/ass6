package Subtask3;

public enum Transports {
    Ship,Truck
}
