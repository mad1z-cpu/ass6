package Subtask3;

public interface Transport {
    public void deliver();
}
