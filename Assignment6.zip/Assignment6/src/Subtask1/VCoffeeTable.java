package Subtask1;

public class VCoffeeTable implements CoffeeTable{
    public void hasCoffee() {
        System.out.println("Victorian CoffeeTable has 8 cups");
    }
    public void hasSeats() {
        System.out.println("Victorian CoffeeTable has 4 seats");
    }
}
