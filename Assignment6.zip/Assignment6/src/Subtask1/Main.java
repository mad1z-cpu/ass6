package Subtask1;

public class Main {

}
