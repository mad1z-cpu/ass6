package Subtask1;

public class VSofa {
}
