package Subtask1;

public class ArtDecoSofa implements Sofa{
    public void hasLegs() {
        System.out.println("ArtDecoSofa has 4 legs;");
    }


    public void setOn() {
        System.out.println("Can sit on ArtDecoSofa");
    }


    public void hasSeats() {
        System.out.println("ArtDeco sofa has 5 seats;");
    }


    public void lieOn() {
        System.out.println("Can lie on ArtDeco sofa");
    }
}
