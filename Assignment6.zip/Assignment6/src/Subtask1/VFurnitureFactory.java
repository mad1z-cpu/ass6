package Subtask1;

public class VFurnitureFactory implements FurnitureFactory{
    public Chair createChair() {
        return new VChair() {
            @Override
            public void hasLegs() {

            }

            @Override
            public void setOn() {

            }

            @Override
            public void hasSeats() {

            }
        };
    }


    public Sofa createSofa() {
        return (Sofa) new VSofa();
    }


    public CoffeeTable createCoffeeTable() {
        return new VCoffeeTable();
    }
}
