package Subtask1;

public interface Sofa {
    public void hasLegs();
    public void setOn();
    public void hasSeats();
    public void lieOn();
}
