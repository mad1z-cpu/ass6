package Subtask1;

public interface Chair {
    public void hasLegs();
    public void setOn();
    public void hasSeats();
}
