package Subtask1;

public class ArtDecoChair implements Chair{
    public void hasLegs() {
        System.out.println("ArtDeco Chair has 3 legs");
    }


    public void setOn() {
        System.out.println("Can sit on artDeco");
    }


    public void hasSeats() {
        System.out.println("ArtDeco Chair has 2 seats");
    }
}
