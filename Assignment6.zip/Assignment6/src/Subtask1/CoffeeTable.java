package Subtask1;

public interface CoffeeTable {
    public void hasCoffee();
    public void hasSeats();
}
