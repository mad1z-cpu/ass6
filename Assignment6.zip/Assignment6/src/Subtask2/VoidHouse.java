package Subtask2;

public interface VoidHouse {
    public House.HouseBuilder setAddress(String add);
    public House.HouseBuilder setVolume(int vol);
    public House.HouseBuilder setQuantityOfRooms(int a);
    public House.HouseBuilder setQuantityOfRestrooms(int a);
    public House.HouseBuilder setPrice(int b);
}
